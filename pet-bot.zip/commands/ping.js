module.exports = (client, msg) => {
    msg.reply('pong');
}